import logging
import azure.functions as func
 
from PIL import Image
from io import BytesIO
import base64
 
 
new_width = 180
chars = ["@", "#", "$", "%", "?", "*", "+", ";", ":", ",", "."]
 
def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP endpoint triggered.')
 
    image_obj = {}
    try:
        req_body = req.get_json()
    except ValueError:
        pass
    else:
        image_obj = req_body.get('image_obj')
     
    if not image_obj:
        return func.HttpResponse(
            "Please send base64 'image_obj' argument",
            status_code=422
        )
 
    img = Image.open(BytesIO(base64.b64decode(image_obj)))
 
    width, height = img.size
    aspect_ratio = height/width
    new_height = aspect_ratio * new_width * 0.55
    img = img.resize((new_width, int(new_height)))
 
    img = img.convert('L')
     
    pixels = img.getdata()
 
    new_pixels = [chars[pixel//25] for pixel in pixels]
    new_pixels = ''.join(new_pixels)
 
    new_pixels_count = len(new_pixels)
    ascii_image = [new_pixels[index:index + new_width] for index in range(0, new_pixels_count, new_width)]
    ascii_image = "\n".join(ascii_image)
 
    logging.info(ascii_image)
 
    return func.HttpResponse(
        ascii_image,
        status_code=200
    )