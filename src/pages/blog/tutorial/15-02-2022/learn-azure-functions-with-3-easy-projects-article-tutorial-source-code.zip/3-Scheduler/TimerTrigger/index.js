const nodemailer = require("nodemailer");

module.exports = async function (context, myTimer) {
  let testAcc = await nodemailer.createTestAccount();

  let transporter = nodemailer.createTransport({
    host: "smtp.ethereal.email",
    port: 587,
    secure: false,
    auth: {
      user: testAcc.user,
      pass: testAcc.pass,
    },
  });

  let messageInfo = await transporter.sendMail({
    from: '"Examle" <foo@example.com>',
    to: "bar@example.com, baz@example.com",
    subject: "Example email",
    text: "Hello world",
  });

  console.log("Preview URL: %s", nodemailer.getTestMessageUrl(messageInfo));
};
